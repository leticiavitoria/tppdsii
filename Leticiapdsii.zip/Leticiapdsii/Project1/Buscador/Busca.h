#ifndef BUSCA_H_
#define BUSCA_H_

#include <string>
#include <map>
#include <set>

using std::string;

class Busca {
public:
	void Insere_Arquivo(string nomeArquivo, string caminhoArquivo);
	int Quantidade_Arquivos();
	int Quantidade_Palavras();
	void Sapeca_Tudo(); //Fun��o para debugar
	Busca();

private:
	//Variables
	std::map<string, string> arquivos_;
	std::map<string, std::map<string, int>> palavras_;

	//Functions
	void Ler_Arquivo(string nomeArquivo);
	string Normaliza_Texto(string texto);
	void Adiciona_Palavra(string palavra);

};
#endif