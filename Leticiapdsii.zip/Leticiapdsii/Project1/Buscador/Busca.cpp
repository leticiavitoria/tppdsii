#include "Busca.h"
#include <iostream> //remover
#include <string>
#include <fstream>
#include <algorithm>
#include <map>

using std::string;


void Busca::Insere_Arquivo(string nomeArquivo, string caminhoArquivo) 
{
	this->arquivos_[nomeArquivo] = caminhoArquivo;
}

int Busca::Quantidade_Arquivos() 
{
	return this->arquivos_.size();
}

int Busca::Quantidade_Palavras()
{
	return this->palavras_.size();
}

void Busca::Sapeca_Tudo() //Fun��o exclusiva para debug
{
	Ler_Arquivo("Doc1.txt");
	Ler_Arquivo("Doc2.txt");
}

Busca::Busca()
{
}

void Busca::Ler_Arquivo(string nomeArquivo)
{
	
	if (this->arquivos_.find(nomeArquivo) == this->arquivos_.end())
		return;
	string caminhoArquivo = this->arquivos_.find(nomeArquivo)->second;
	std::ifstream arquivo(caminhoArquivo);
	string palavraArquivo;
	if (arquivo.is_open()) {
		while (!arquivo.eof()) {
			std::getline(arquivo, palavraArquivo, ' ');
			palavraArquivo = this->Normaliza_Texto(palavraArquivo);
			if (this->palavras_.find(palavraArquivo) == this->palavras_.end())
				Adiciona_Palavra(palavraArquivo);
			std::map<string, std::map<string, int>>::iterator mapIterator = this->palavras_.find(palavraArquivo);
			if (mapIterator->second.find(nomeArquivo) == mapIterator->second.end()) {
				mapIterator->second[nomeArquivo] = 1;
			}
			else
			{
				mapIterator->second[nomeArquivo] = mapIterator->second[nomeArquivo]++;
			}
		}
		arquivo.close();
	}
}

string Busca::Normaliza_Texto(string texto) 
{
	char * charTexto = (char*)texto.c_str();
	for (int i = 0; charTexto[i] != NULL; i++)
	{
		if (int(charTexto[i]) >= 65 && int(charTexto[i]) <= 90) //Transforma ma�scula em min�scula
			charTexto[i] = charTexto[i] + 32;
		else if ((int(charTexto[i]) >= 97 && int(charTexto[i]) <= 122) || int(charTexto[i]) >= 48 && int(charTexto[i]) <= 57) {} //Min�scula e num. -> Fa�o nada
		else
			charTexto[i] = 33; //Transformo qualquer caractere diferente dos mencionados em '!'	
	}
	texto = (string)charTexto;
	texto.erase(std::remove(texto.begin(), texto.end(), '!'), texto.end());
	return texto;
}

void Busca::Adiciona_Palavra(string palavra)
{
	std::map<string, int> newMap = std::map<string, int>();
	this->palavras_[palavra] = newMap;
}