#include <iostream>
#include "Busca.h"
using std::cout;

int main()
{
	Busca minhaBusca = Busca();
	minhaBusca.Insere_Arquivo("Doc1.txt", "D:\\Dataset\\doc1.txt");
	minhaBusca.Insere_Arquivo("Doc2.txt", "D:\\Dataset\\doc2.txt");
	minhaBusca.Sapeca_Tudo();
	cout << "Quantidade palavras: " << minhaBusca.Quantidade_Palavras() << std::endl;
	cout << "Quantidade arquivos: " << minhaBusca.Quantidade_Arquivos() << std::endl;
	string bolo;
	std::cin >> bolo; //Pausar o debugger
	return 0;
}